#include <iostream>
#include <stdexcept>
#include <cassert>
using namespace std;

int main() {

    return 0;
}
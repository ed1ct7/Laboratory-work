﻿using QRCoder;
using System;
using System.Drawing;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace QRCodeGeneratorApp
{
    public partial class MainWindow : Window
    {
        private BitmapImage qrImage;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Создание QR-кода
        private void CreateQR_Click(object sender, RoutedEventArgs e)
        {
            string text = DataTextBox.Text.Trim();

            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Введите текст!");
                return;
            }

            var generator = new QRCodeGenerator();
            var data = generator.CreateQrCode(text, QRCodeGenerator.ECCLevel.Q);
            var qrCode = new QRCode(data);
            Bitmap bmp = qrCode.GetGraphic(20);

            qrImage = ConvertBitmap(bmp);
            QrImage.Source = qrImage;
        }

        // Конвертация Bitmap → BitmapImage
        private BitmapImage ConvertBitmap(Bitmap bmp)
        {
            var ms = new MemoryStream();
            bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            ms.Position = 0;

            var img = new BitmapImage();
            img.BeginInit();
            img.StreamSource = ms;
            img.CacheOption = BitmapCacheOption.OnLoad;
            img.EndInit();
            return img;
        }

        // Сохранение по двойному клику
        private void QrImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount != 2 || qrImage == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PNG файл|*.png",
                FileName = "qrcode.png"
            };

            if (dialog.ShowDialog() == true)
            {
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(qrImage));
                using var file = File.Create(dialog.FileName);
                encoder.Save(file);

                MessageBox.Show("QR-код сохранён!");
            }
        }
    }
}
